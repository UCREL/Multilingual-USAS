#!/bin/sh

java -jar UcrelSemTaggerPublicGUI.jar



