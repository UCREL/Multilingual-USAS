Instruction:

This is a desktop user interface for accessing the Lancaster University UCREL semantic tagger web services (http://ucrel.lancs.ac.uk/usas/), including USAS multilingual semantic tagger and HTST English semantic tagger developed in SAMUELS Project (http://www.gla.ac.uk/schools/critical/research/fundedresearchprojects/samuels/).

This is for non-commercial use only.

How to run:
1) On Windows PCs, click on the file "UcrelSemTaggerGUI.jar".
2) On Linux or Mac PCs, use command "java -jar UcrelSemTaggerGUI.jar" or
execute the "run_semtagger_gui.sh" file.

If you have any queries, please contact Scott Piao (s.piao@lancaster.ac.uk) or Paul Rayson (p.rayson@lancaster.ac.uk) of School of Computing and Communications, Lancaster University, UK.

Reference Papers Related to This Tool:
Piao, Scott, Fraser Dallachy, Alistair Baron, Jane Demmen, Steve Wattam, Philip Durkin, James McCracken, Paul Rayson, Marc Alexander (2017). Time-Sensitive Historical Thesaurus-based Semantic Tagger for Deep Semantic Annotation . Computer Speech and Language, vol. 46, Elsevier. pp. 113-135. doi:10.1016/j.csl.2017.04.010.

Piao, Scott, Paul Rayson, Dawn Knight, Gareth Watkins and Kevin Donnelly (2017). Towards a Welsh Semantic Tagger: Creating Lexicons for A Resource Poor Language. The Corpus Linguistics 2017 Conference, 24-28 July 2017 at University of Birmingham, Birmingham, UK.

Piao, Scott, Paul Rayson, Dawn Archer, Francesca Bianchi, Carmen Dayrell, Mahmoud El-Haj, Ricardo-María Jiménez, Dawn Knight, Michal Křen, Laura Löfberg, Rao Muhammad Adeel Nawab, Jawad Shafi, Phoey Lee Teh, Olga Mudraya (2016). Lexical Coverage Evaluation of Large-scale Multilingual Semantic Lexicons for Twelve Languages. In Proceedings of The 10th Edition of the Language Resources and Evaluation Conference (LREC2016), held during 23-28 May 2016 in Portorož, Slovenia.

Piao, Scott, Francesca Bianchi, Carmen Dayrell, Angela D'Egidio and Paul Rayson (2015). Development of the Multilingual Semantic Annotation System. The 2015 Conference of the North American Chapter of the Association for Computational Linguistics – Human Language Technologies (NAACL HLT 2015), Denver, Colorado, USA.

Alexander, Marc, Fraser Dallachy, Scott Piao, Alistair Baron, Paul Rayson (2015). Metaphor, Popular Science and Semantic Tagging: Distant reading with the Historical Thesaurus of English. Digital Scholarship in the Humanities, Oxford University Press, UK.

Rayson, Paul, Dawn Archer, Scott Piao and Tony McEnery (2004). The UCREL semantic analysis system. In Proceedings of LREC-04 Workshop: Beyond Named Entity Recognition Semantic Labeling for NLP Tasks, pp. 7-12. Lisbon, Portugal.

